# Crazy Balls

This is an animation and interaction project developed using HTML and CSS only.

There is actually not so much more to say: _check it out **[here](https://tinf9.github.io/crazyBalls/)**!_

![Crazy Balls sample image](/sample-image.png)
